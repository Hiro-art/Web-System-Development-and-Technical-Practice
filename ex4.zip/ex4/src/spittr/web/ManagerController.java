package spittr.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import spittr.db.ManagerRepository;
import spittr.db.SpitterRepository;
import spittr.db.SpittleRepository;
import spittr.domain.Manager;
import spittr.domain.Spittle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.Date;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

/**
 * 管理员控制类
 * @author Xiaoning Jia
 */
@Controller
@SessionAttributes({ "manager" })
@RequestMapping("/manager")

public class ManagerController {

    @Autowired
    private ManagerRepository managerRepository;
    @Autowired
    private SpitterRepository spitterRepository;
    @Autowired
    private SpittleRepository spittleRepository;
    /**
     * 管理员登陆
     *
     * @return
     */
    @RequestMapping(value = "/login", method = GET)
    public String showManagerLogin(){
        return "ManagerLogin";
    }

    @RequestMapping(value = "/page", method = GET)
    public String getPage(@RequestParam(value = "page") String page) {
        return page;
    }

    @RequestMapping(value = "/update",method = GET)
    public String showManagerUpdate(){
        return "ManagerUpdate";
    }

    @RequestMapping(value = "/update",method = POST)
    public String update(@RequestParam(value = "userName",  defaultValue = "")String userName,
                         @RequestParam(value = "password",  defaultValue = "")String password,
                         @RequestParam(value = "email", defaultValue = "") String email,
                         @RequestParam(value = "phoneNo", defaultValue = "")String phoneNo, Model model){
        boolean manager = managerRepository.updatePassword(userName, password, email, phoneNo);
        return "ManagerView";
    }
    /**
     * 请求登录
     * @param userName
     * @param password
     * @param session
     * @return
     */
    @RequestMapping(value = "/login", method = POST)
    public String processManagerLogin(@RequestParam(value = "userName", defaultValue = "") String userName,
                                      @RequestParam(value = "password", defaultValue = "") String password, HttpSession session, HttpServletRequest request){
        Manager manager =managerRepository.findByUserName(userName, password);
        if(manager != null && manager.getIsDelete() != 0){
            session.setAttribute("manager",manager);
            return "ManagerView";
        }else {
            return "loginError";
        }
    }

    @RequestMapping(value = "/check_manager",method = GET)
    public String managerList(@RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
                              @RequestParam(value = "pageSize", defaultValue = "10") int pageSize, Model model){
        if (pageSize <= 0){
            pageSize = PaginationSupport.PAGESIZE;
        }
        model.addAttribute("managerlist",managerRepository.findPage(pageNo, pageSize));
        return "ManagerList";
    }

    @RequestMapping(value = "/check_spitter",method = GET)
    public String spitterList(@RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
                              @RequestParam(value = "pageSize", defaultValue = "10") int pageSize, Model model){
        if (pageSize <= 0){
            pageSize = PaginationSupport.PAGESIZE;
        }
        model.addAttribute("spitterlist",spitterRepository.findPage(pageNo,pageSize));
        return "SpittlerList";
    }

    @RequestMapping(value = "/examine",method = GET)
    public String UPS(){
        return "SpittleUpdate";
    }

    @RequestMapping(value = "/examine",method = POST)
    public String UPs(@RequestParam(value = "id", defaultValue = "") long id,HttpSession session){
        Date check_time = new Date();
        Manager manager = (Manager) session.getAttribute("manager");
        long check_id =manager.getId();
        System.out.println(check_id + ", " + manager.getUserName());
        spittleRepository.updateSpittle(check_id,check_time,id);
        return "Successful";
    }

    @RequestMapping(value = "/check_spittle",method = GET)
    public String spittleList(@RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
                              @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,Model model) {

        if (pageSize <= 0){
            pageSize = PaginationSupport.PAGESIZE;
        }
        PaginationSupport<Spittle> tt = spittleRepository.findPage(pageNo,pageSize);
        for (Spittle s: tt.getItems()) {
            System.out.println(s.getIschecked());
        }
        model.addAttribute("spittlelist", tt);
        return "SpittleList";
    }

    @RequestMapping(value = "/add", method = GET)
    public String showAddManager(Model model) {

        return "registerManager";
    }
    @RequestMapping(value = "/delete",method = POST)
    public String mDelete(@RequestParam(value = "userName",  defaultValue = "")String userName){
        int isDelete = 0;
        boolean manager = managerRepository.DeleteManager(userName,isDelete);
        return "Successful";
    }

    @RequestMapping(value = "/deletespittle",method = GET)
    public String spittleD(){
        return "SpittleDelete";
    }
    @RequestMapping(value = "/deletespittle",method = POST)
    public String spittleDelete(@RequestParam(value = "id", defaultValue = "") long id){
        spittleRepository.delete(id);
        return "Successful";
    }

    @RequestMapping(value = "/add", method = POST)
    public String processRegistration(@Valid Manager manager, Errors errors) {
        if (errors.hasErrors()) {
            return "registerManager";
        }

        manager = managerRepository.save(manager);
        return "Successful";
    }
    @RequestMapping(value = "/delete",method = GET)
    public String managerDelete(){
        return "ManagerDelete";
    }
}
