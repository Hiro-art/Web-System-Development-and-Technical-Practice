package spittr.web;
import java.util.List;

/**
 * 分页辅助功能类
 * @author Xiaoning Jia
 * @param <T>
 */
public class PaginationSupport<T> {
    //全部记录
    private List<T> items;
    //页面总数
    private int totality;
    //页面默认大小
    public final static int PAGESIZE = 10;
    //页面大小
    private int pageSize = PAGESIZE;
    //记录起始索引数组
    private int[] indexes = new int[0];
    //起始记录索引
    private int startIndex = 0;

    /**
     * 分页辅助功能的构造方法。
     * @param items 数据记录。
     * @param totality 总记录数。
     */
    public PaginationSupport(List<T> items, int totality) {
        setPageSize(PAGESIZE);
        setTotality(totality);
        setItems(items);
        setStartIndex(0);
    }

    /**
     * 分页辅助功能的构造方法。
     * @param items 数据记录。
     * @param totality 总记录数。
     * @param startIndex 起始记录索引。
     */
    public PaginationSupport(List<T> items, int totality, int startIndex) {
        setPageSize(PAGESIZE);
        setTotality(totality);
        setItems(items);
        setStartIndex(startIndex);
    }

    /**
     * 分页辅助功能的构造方法。
     * @param items 数据记录。
     * @param totality 总记录数。
     * @param pageSize 页面大小。
     * @param startIndex 起始记录索引。
     */
    public PaginationSupport(List<T> items, int totality, int pageSize, int startIndex) {
        setPageSize(pageSize);
        setTotality(totality);
        setItems(items);
        setStartIndex(startIndex);
    }

    /**
     * 将页码转换为列表的startIndex。
     * @param pageNo 页码。
     * @return 起始记录索引号。
     */
    public static int convertFromPageToStartIndex(int pageNo) {
        return (pageNo - 1) * PAGESIZE;
    }

    /**
     * 将页码转换为列表的startIndex。
     * @param pageNo 页码。
     * @param pageSize 页面大小。
     * @return 起始记录索引号。
     */
    public static int convertFromPageToStartIndex(int pageNo, int pageSize) {
        return (pageNo - 1) * pageSize;
    }

    public List<T> getItems() {
        return items;
    }
    public void setItems(List<T> items) {
        this.items = items;
    }
    public int getPageSize() {
        return pageSize;
    }
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
    public int getTotality() {
        return totality;
    }

    /**
     * 设置数据总数为指定值，并计算各页起始位置。
     * @param totality 总记录数
     */
    public void setTotality(int totality) {
        if (totality > 0) {
            this.totality = totality;
            int count = totality / pageSize;
            if (totality % pageSize > 0)
                count++;
            indexes = new int[count];
            for (int i = 0; i < count; i++) {
                indexes[i] = pageSize * i;
            }
        } else {
            this.totality = 0;
        }
    }
    public int[] getIndexes() {
        return indexes;
    }
    public void setIndexes(int[] indexes) {
        this.indexes = indexes;
    }
    public int getStartIndex() {
        return startIndex;
    }

    /**
     * 设置起始记录索引为指定值，设置当前起始位置。
     * @param startIndex 起始记录索引。
     */
    public void setStartIndex(int startIndex) {
        if (totality <= 0)
            this.startIndex = 0;
        else if (startIndex >= totality)
            this.startIndex = indexes[indexes.length - 1];
        else if (startIndex < 0)
            this.startIndex = 0;
        else {
            this.startIndex = indexes[startIndex / pageSize];
        }
    }
    /**
     * 是否有下一页。
     * @return true有下一页，false无。
     */
    public boolean isNextPage() {
        return this.getCurrentPageNo() < this.getTotalPageCount();
    }
    /**
     * 是否有上一页。
     * @return true有上一页，false无。
     */
    public boolean isPreviousPage() {
        return this.getCurrentPageNo() > 1;
    }
    /**
     * 获得下页起始位置。
     * @return 下页起始记录索引。
     */
    public int getNextIndex() {
        int nextIndex = getStartIndex() + pageSize;
        if (nextIndex >= totality)
            return getStartIndex();
        return nextIndex;
    }
    /**
     * 获得上页起始位置。
     * @return 上页起始记录索引。
     */
    public int getPreviousIndex() {
        int previousIndex = getStartIndex() - pageSize;
        if (previousIndex < 0)
            return 0;
        return previousIndex;
    }
    /**
     * 取总页数。
     * @return 总页数。
     */
    public long getTotalPageCount() {
        if (totality % pageSize == 0)
            return totality / pageSize;
        return totality / pageSize + 1;
    }
    /**
     * 取该页当前页码,页码从1开始。
     * @return 当前页码。
     */
    public long getCurrentPageNo() {
        return startIndex / pageSize + 1;
    }


}
