package spittr.domain;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;

/**
 * Manager类的实现
 * @author Xiaoning Jia
 */
public class Manager {
    private Long id;
    @NotNull
    @Size(min = 5,max = 16)
    private String userName;

    @NotNull
    @Size(min = 5,max = 25)
    private String password;

    @NotNull
    @Size(min = 1,max = 30)
    private String fullName;

    @NotNull
    @Email
    private String email;

    @NotNull
    @Size(min = 11,max = 20)
    private String phoneNo;

    @NotNull
    private int isDelete;
    /**
     * 构造方法
     * @param userName     管理员用户名（登录名）
     * @param password      密码
     * @param fullName      管理员姓名
     * @param email         邮箱
     * @param phoneNo       电话号码
     * @param isDelete      删除标记
     */
    public Manager(Long id, String userName, String password, String fullName, String email, String phoneNo, int isDelete){
        this.id = id;
        this.userName = userName;
        this.password = password;
        this.fullName = fullName;
        this.email = email;
        this.phoneNo = phoneNo;
        this.isDelete = isDelete;
    }
    public Manager(String userName, String password, String fullName, String email, String phoneNo, int isDelete){
        this(null,userName,password,fullName,email,phoneNo,isDelete);
    }
    public String getUserName(){
        return userName;
    }
    public void setUserName(String userName){
        this.userName = userName;
    }
    public Long getId(){
        return id;
    }
    public void setId(Long id){
        this.id = id;
    }
    public String getFullName(){
        return fullName;
    }
    public void setFullName(String fullName){
        this.fullName = fullName;
    }
    public String getPassword(){
        return password;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPhoneNo() {
        return phoneNo;
    }
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }
    public int getIsDelete() {
        return isDelete;
    }
    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }
    @Override
    public String toString() {
        return "Manager{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", fullName='" + fullName + '\'' +
                ", email='" + email + '\'' +
                ", phoneNo='" + phoneNo + '\'' +
                ", isDelete=" + isDelete +
                '}';
    }
    @Override
    public int hashCode() {
        final int primary = 31;
        int result = 1;
        result = primary * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Manager manager = (Manager) o;
        return id.equals(manager.id);
    }


}
