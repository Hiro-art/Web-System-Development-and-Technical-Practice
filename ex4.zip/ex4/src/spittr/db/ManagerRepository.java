package spittr.db;

import spittr.domain.Manager;
import spittr.web.PaginationSupport;

import java.util.List;

/**
 * 管理员资源接口
 * @author Xiaoning Jia
 */
public interface ManagerRepository {
    //获得管理员数量
    long count();
    /**
     * 创建一个管理员用户
     * @param manager 新建的管理员
     * @return 管理员用户
     */
    Manager save(Manager manager);
    /**
     * 按照管理员的登录名来查找管理员
     * @param userName 登录名
     * @return 目标管理员
     */
    Manager findByUserName(String userName);
    /**
     * 按照id查找管理员
     * @param id 管理员id
     * @return 目标管理员
     */
    Manager findOne(long id);
    /**
     * 按照用户名和密码来查找管理员
     * @param userName
     * @param password
     * @return 目标管理员
     */
    Manager findByUserName(String userName, String password);
    /**
     * 获取全部管理员
     * @return 全部管理员
     */
    List<Manager> findAll();

    boolean updatePassword(String username, String password, String email, String phoneNo);
    boolean DeleteManager(String username, int isDelete);
    PaginationSupport<Manager> findPage(int pageNo, int pageSize);
}
